import { Component, OnInit } from '@angular/core';
import {ProductService} from './app.productService';
import { Product } from './Product';

@Component({
    selector:'show-app',
    templateUrl:'show.product.html'
})
export class ShowProductComponent implements OnInit{
     constructor(private prodservice:ProductService){}
     prodAll:any[];
     ngOnInit(){
        this.prodservice.getAllProduct().subscribe((data:any)=>this.prodAll=data);
    }

}