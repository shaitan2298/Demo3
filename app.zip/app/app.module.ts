﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { Routes,RouterModule  } from '@angular/router';
import { Customer } from './app.customerComponent';
import { FormsModule, FormBuilder, FormGroup }from '@angular/forms';
const router:Routes=[
    {path:'customer',component:Customer}
]
@NgModule({
    imports: [
        BrowserModule,RouterModule,HttpClientModule,FormsModule,RouterModule.forRoot(router)
        
    ],
    declarations: [
        AppComponent,Customer
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }