import {Component,OnInit} from '@angular/core';
import {ProductService} from './app.productService';
import { Product } from './Product';
import { Routes,RouterModule,Router  } from '@angular/router';

@Component({
    selector:'add-prod',
    templateUrl:'add.product.html'
})

export class AddProduct{
    constructor(private prodservice:ProductService,private router:Router){}
    prod:any={};
  
    
    addProduct():any{
        //alert(this.prod.prodId + " " + this.prod.prodName);
        this.prodservice.addProduct(this.prod).subscribe((data)=>console.log(data));
        this.router.navigate(['show']);
    }
}