import {Injectable} from '@angular/core'
import {HttpClient} from '@angular/common/http'

@Injectable({
    providedIn:'root'
})

export class ProductService{
 
    constructor(private httpdata:HttpClient){}

    getAllProduct(){
        return this.httpdata.get("http://localhost:9098/getAllProductDetails");
    }
    addProduct(data:any){
        console.log(data.prodId);
        let input=new FormData();
        input.append("prodId",data.prodId);
        input.append("prodName",data.prodName);
        input.append("prodPrice",data.prodPrice);
        input.append("prodStatus",data.prodStatus);
        return this.httpdata.post("http://localhost:9098/acceptProductDetails",input);
    }

}