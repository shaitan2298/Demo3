import {Injectable} from '@angular/core'
import {HttpClient} from '@angular/common/http'

@Injectable({
    providedIn:'root'
})

export class CustomerService{
 
    constructor(private httpdata:HttpClient){}

    getAllCustomer(){
        return this.httpdata.get("http://localhost:8099/getAllCustomerDetails");    }
    addCustomer(data:any){
        console.log(data.customerFullName);
        let input=new FormData();
        input.append("customerFullName",data.customerFullName);
        input.append("customerEmail",data.customerEmail);
        input.append("password",data.password);
        input.append("customerPhoneNumber",data.customerPhoneNumber);
        input.append("customerAddress",data.customerAddress);
        input.append("customerZipCode",data.customerZipCode);
        input.append("customerCity",data.customerCity);
        input.append("country",data.country);
        return this.httpdata.post("http://localhost:8099/acceptCustomerDetails",input);
    }

deleteCustomer(data:any){
    
    return this.httpdata.delete("http://localhost:8099/deleteCustomer/"+data);
}

}