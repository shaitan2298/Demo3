import {Component,OnInit} from '@angular/core';
import {CustomerService} from './app.customerServices';
import { Routes,RouterModule,Router  } from '@angular/router'; 
@Component({
    selector:'add-prod',
    templateUrl:'add.customer.html'
})

export class Customer implements OnInit{
    constructor(private custservice:CustomerService,private router:Router){}
    cust:any={};
    custAll:any[];
    ngOnInit(){
        this.custservice.getAllCustomer().subscribe((data:any)=>this.custAll=data);
    }

     deleteCustomer(i:number):any{
       
        this.custservice.deleteCustomer(i).subscribe();
    }

    addCustomer():any{
        //alert(this.prod.prodId + " " + this.prod.prodName);
        this.custservice.addCustomer(this.cust).subscribe((data)=>console.log(data));
    }
}