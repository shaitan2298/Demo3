export class Product{
    prodId:number;
    prodName:string;
    prodPrice:number;
    prodStatus:boolean;
}