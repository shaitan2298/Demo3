﻿import { Component } from '@angular/core';

@Component({
    selector: 'app',
    templateUrl: 'app.component.html'
})

export class AppComponent {
     title:any = true;
  addCustomer() {
    this.title = true;
  }
 }